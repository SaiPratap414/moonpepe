(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 6389:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__txtgroovysmooth_f9b56f', '__txtgroovysmooth_Fallback_f9b56f'","fontWeight":400},
	"className": "__className_f9b56f",
	"variable": "__variable_f9b56f"
};


/***/ }),

/***/ 140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ App)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/@next/font/local/target.css?{"path":"src\\pages\\_app.tsx","import":"","arguments":[{"src":[{"path":"../../public/fonts/txtgroovysmooth.ttf","weight":"400"}],"variable":"--font-txtgroovysmooth"}],"variableName":"txtgroovysmooth"}
var txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_ = __webpack_require__(6389);
var txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_default = /*#__PURE__*/__webpack_require__.n(txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_);
;// CONCATENATED MODULE: external "styled-jsx/style"
const style_namespaceObject = require("styled-jsx/style");
var style_default = /*#__PURE__*/__webpack_require__.n(style_namespaceObject);
// EXTERNAL MODULE: ./src/styles/globals.scss
var globals = __webpack_require__(6961);
;// CONCATENATED MODULE: ./src/pages/_app.tsx




function App({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            jsx_runtime_.jsx((style_default()), {
                id: "134bc91aa7e046b2",
                dynamic: [
                    (txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_default()).style.fontFamily
                ],
                children: `*{font-family:${(txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_default()).style.fontFamily}}`
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps,
                className: style_default().dynamic([
                    [
                        "134bc91aa7e046b2",
                        [
                            (txtgroovysmooth_ttf_weight_400_variable_font_txtgroovysmooth_variableName_txtgroovysmooth_default()).style.fontFamily
                        ]
                    ]
                ]) + " " + (pageProps && pageProps.className != null && pageProps.className || "")
            }),
            ";"
        ]
    });
}


/***/ }),

/***/ 6961:
/***/ (() => {



/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(140));
module.exports = __webpack_exports__;

})();